#!/usr/bin/env bash
# =============================================================================
# Blue Team MCP Server - Setup Script
# =============================================================================
# Run this on your DEFENDER HOST (Ubuntu/Debian recommended)
# Usage: sudo bash setup.sh
# =============================================================================

set -e

INSTALL_DIR="/opt/blue-team-mcp"
SERVICE_USER="blueteam-mcp"

echo "=============================================="
echo "  Blue Team MCP Server - Setup"
echo "=============================================="

# ── Root check ────────────────────────────────────
if [[ $EUID -ne 0 ]]; then
  echo "Please run as root: sudo bash setup.sh"
  exit 1
fi

# ── Install system dependencies ───────────────────
echo "[1/6] Installing system packages..."
apt-get update -qq
apt-get install -y --no-install-recommends \
  python3 python3-pip python3-venv \
  tcpdump \
  fail2ban \
  rkhunter \
  chkrootkit \
  lynis \
  net-tools \
  iproute2 \
  procps \
  openssh-server \
  2>/dev/null || true

echo "[2/6] Creating install directory at $INSTALL_DIR..."
mkdir -p "$INSTALL_DIR"
cp blue_team_server.py "$INSTALL_DIR/"
cp requirements.txt "$INSTALL_DIR/"

# ── Python venv ───────────────────────────────────
echo "[3/6] Setting up Python virtual environment..."
python3 -m venv "$INSTALL_DIR/venv"
"$INSTALL_DIR/venv/bin/pip" install --quiet --upgrade pip
"$INSTALL_DIR/venv/bin/pip" install --quiet -r "$INSTALL_DIR/requirements.txt"

# ── Wrapper script ────────────────────────────────
echo "[4/6] Creating mcp-server wrapper script..."
cat > /usr/local/bin/mcp-server-blueteam << 'EOF'
#!/usr/bin/env bash
# Wrapper - Claude Desktop calls this via SSH
export ABUSEIPDB_API_KEY="${ABUSEIPDB_API_KEY:-}"
export VIRUSTOTAL_API_KEY="${VIRUSTOTAL_API_KEY:-}"
exec /opt/blue-team-mcp/venv/bin/python3 /opt/blue-team-mcp/blue_team_server.py "$@"
EOF
chmod +x /usr/local/bin/mcp-server-blueteam

# ── SSH hardening reminder ────────────────────────
echo "[5/6] Ensuring SSH is running..."
systemctl enable --now ssh 2>/dev/null || systemctl enable --now sshd 2>/dev/null || true

# ── Capability grants (allow tcpdump without root) ─
echo "[6/6] Granting tcpdump network capture capability..."
setcap cap_net_raw,cap_net_admin=eip "$(which tcpdump)" 2>/dev/null || \
  echo "  WARNING: Could not set tcpdump capabilities. Run captures as root."

# ── API key configuration ─────────────────────────
echo ""
echo "=============================================="
echo "  Setup complete!"
echo "=============================================="
echo ""
echo "OPTIONAL: Set API keys for threat intel tools:"
echo ""
echo "  # AbuseIPDB (free tier available)"
echo "  echo 'export ABUSEIPDB_API_KEY=your_key' >> /etc/environment"
echo "  # https://www.abuseipdb.com/account/api"
echo ""
echo "  # VirusTotal (free tier available)"
echo "  echo 'export VIRUSTOTAL_API_KEY=your_key' >> /etc/environment"
echo "  # https://www.virustotal.com/gui/my-apikey"
echo ""
echo "Then add to your Claude Desktop config on macOS/Windows:"
echo ""
echo '  {
    "mcpServers": {
      "blue-team-mcp": {
        "command": "ssh",
        "args": [
          "-i", "/path/to/your/ssh_key",
          "user@DEFENDER_HOST_IP",
          "mcp-server-blueteam"
        ],
        "transport": "stdio"
      }
    }
  }'
echo ""
echo "Test locally first: mcp-server-blueteam"
