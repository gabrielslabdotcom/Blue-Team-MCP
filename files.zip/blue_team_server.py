"""
Blue Team MCP Server
====================
A defensive security MCP server for Claude Desktop, mirroring the Kali
mcp-kali-server setup but for blue team / defenders.

Tools included:
  - Log analysis (auth, syslog, journald, nginx/apache)
  - Network monitoring (open ports, active connections, traffic capture)
  - Threat intelligence (IP/domain reputation via AbuseIPDB, VirusTotal)
  - Fail2ban management (view jails, banned IPs, unban)
  - File integrity checking (AIDE/manual hash comparison)
  - System hardening audit (Lynis, open SUID files, world-writable paths)
  - User & session monitoring (who is logged in, sudo history)
  - CVE / vulnerability lookup

Usage:
  pip install mcp httpx pydantic
  python blue_team_server.py

Claude Desktop config (claude_desktop_config.json):
  {
    "mcpServers": {
      "blue-team-mcp": {
        "command": "ssh",
        "args": ["-i", "/path/to/key", "user@DEFENDER_HOST", "python3 /opt/blue-team-mcp/blue_team_server.py"],
        "transport": "stdio"
      }
    }
  }
"""

import asyncio
import json
import subprocess
import shutil
import os
import hashlib
import re
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, List, Dict, Any

import httpx
from pydantic import BaseModel, Field, ConfigDict
from mcp.server.fastmcp import FastMCP

# ---------------------------------------------------------------------------
# Server init
# ---------------------------------------------------------------------------
mcp = FastMCP("blue_team_mcp")

# ---------------------------------------------------------------------------
# Configuration (set via environment variables)
# ---------------------------------------------------------------------------
ABUSEIPDB_API_KEY = os.environ.get("ABUSEIPDB_API_KEY", "")
VIRUSTOTAL_API_KEY = os.environ.get("VIRUSTOTAL_API_KEY", "")
MAX_LOG_LINES = 2000   # safety cap for log reads
TIMEOUT = 30           # seconds for subprocess calls


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _run(cmd: List[str], timeout: int = TIMEOUT) -> Dict[str, Any]:
    """Run a shell command and return stdout/stderr/returncode dict."""
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout
        )
        return {
            "stdout": result.stdout,
            "stderr": result.stderr,
            "returncode": result.returncode,
        }
    except subprocess.TimeoutExpired:
        return {"stdout": "", "stderr": f"Command timed out after {timeout}s", "returncode": -1}
    except FileNotFoundError:
        return {"stdout": "", "stderr": f"Command not found: {cmd[0]}", "returncode": -1}
    except Exception as e:
        return {"stdout": "", "stderr": str(e), "returncode": -1}


def _tool_not_found(tool: str) -> str:
    return json.dumps({
        "error": f"'{tool}' is not installed or not in PATH.",
        "fix": f"Install it with: sudo apt install {tool}  (Debian/Ubuntu)"
    }, indent=2)


def _tail_file(path: str, lines: int) -> str:
    """Return last N lines of a file, with error handling."""
    p = Path(path)
    if not p.exists():
        return json.dumps({"error": f"File not found: {path}"})
    r = _run(["tail", "-n", str(lines), path])
    return r["stdout"] or r["stderr"]


async def _http_get(url: str, headers: Dict[str, str], params: Dict[str, str] = None) -> Dict:
    async with httpx.AsyncClient(timeout=15) as client:
        resp = await client.get(url, headers=headers, params=params or {})
        resp.raise_for_status()
        return resp.json()


# ---------------------------------------------------------------------------
# ─── LOG ANALYSIS ──────────────────────────────────────────────────────────
# ---------------------------------------------------------------------------

class LogInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    lines: int = Field(default=200, description="Number of recent lines to return", ge=1, le=MAX_LOG_LINES)
    grep: Optional[str] = Field(default=None, description="Optional keyword/regex to filter lines (case-insensitive)")


@mcp.tool(
    name="blueteam_read_auth_log",
    annotations={"readOnlyHint": True, "destructiveHint": False}
)
async def blueteam_read_auth_log(params: LogInput) -> str:
    """Read and optionally filter /var/log/auth.log for SSH, sudo, and PAM events.

    Args:
        params.lines (int): How many tail lines to read (default 200, max 2000)
        params.grep (str, optional): Filter to lines containing this pattern

    Returns:
        str: Matching log lines or error JSON
    """
    log_path = "/var/log/auth.log"
    # Fallback for systems using journald only
    if not Path(log_path).exists():
        cmd = ["journalctl", "-u", "ssh", "-n", str(params.lines), "--no-pager"]
        if params.grep:
            cmd += ["--grep", params.grep]
        r = _run(cmd)
        return r["stdout"] or r["stderr"]

    content = _tail_file(log_path, params.lines)
    if params.grep:
        lines = [l for l in content.splitlines() if re.search(params.grep, l, re.IGNORECASE)]
        return "\n".join(lines) if lines else f"No lines matched filter: {params.grep}"
    return content


@mcp.tool(
    name="blueteam_read_syslog",
    annotations={"readOnlyHint": True, "destructiveHint": False}
)
async def blueteam_read_syslog(params: LogInput) -> str:
    """Read /var/log/syslog or journalctl for general system events.

    Args:
        params.lines (int): Lines to return
        params.grep (str, optional): Filter pattern

    Returns:
        str: Log content
    """
    for path in ["/var/log/syslog", "/var/log/messages"]:
        if Path(path).exists():
            content = _tail_file(path, params.lines)
            if params.grep:
                lines = [l for l in content.splitlines() if re.search(params.grep, l, re.IGNORECASE)]
                return "\n".join(lines) if lines else f"No matches for: {params.grep}"
            return content
    # Fallback to journalctl
    cmd = ["journalctl", "-n", str(params.lines), "--no-pager"]
    if params.grep:
        cmd += ["--grep", params.grep]
    r = _run(cmd)
    return r["stdout"] or r["stderr"]


class WebLogInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    server: str = Field(default="nginx", description="Web server: 'nginx' or 'apache'")
    log_type: str = Field(default="access", description="Log type: 'access' or 'error'")
    lines: int = Field(default=200, ge=1, le=MAX_LOG_LINES)
    grep: Optional[str] = Field(default=None, description="Optional filter pattern")


@mcp.tool(
    name="blueteam_read_web_log",
    annotations={"readOnlyHint": True, "destructiveHint": False}
)
async def blueteam_read_web_log(params: WebLogInput) -> str:
    """Read nginx or Apache access/error logs. Great for spotting web attacks.

    Args:
        params.server: 'nginx' or 'apache'
        params.log_type: 'access' or 'error'
        params.lines: Lines to read
        params.grep: Optional filter

    Returns:
        str: Log lines
    """
    paths = {
        "nginx": {
            "access": "/var/log/nginx/access.log",
            "error": "/var/log/nginx/error.log",
        },
        "apache": {
            "access": "/var/log/apache2/access.log",
            "error": "/var/log/apache2/error.log",
        },
    }
    server = params.server.lower()
    if server not in paths:
        return json.dumps({"error": f"Unknown server '{params.server}'. Use 'nginx' or 'apache'."})
    log_type = params.log_type.lower()
    if log_type not in paths[server]:
        return json.dumps({"error": f"Unknown log type '{params.log_type}'. Use 'access' or 'error'."})

    path = paths[server][log_type]
    content = _tail_file(path, params.lines)
    if params.grep:
        lines = [l for l in content.splitlines() if re.search(params.grep, l, re.IGNORECASE)]
        return "\n".join(lines) if lines else f"No matches for: {params.grep}"
    return content


class JournalInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    unit: Optional[str] = Field(default=None, description="Systemd unit name, e.g. 'sshd', 'nginx', 'cron'")
    since: Optional[str] = Field(default="1 hour ago", description="Time range, e.g. '2 hours ago', '2024-01-15 10:00'")
    lines: int = Field(default=200, ge=1, le=MAX_LOG_LINES)
    grep: Optional[str] = Field(default=None)


@mcp.tool(
    name="blueteam_journalctl",
    annotations={"readOnlyHint": True, "destructiveHint": False}
)
async def blueteam_journalctl(params: JournalInput) -> str:
    """Query systemd journal for any service. Useful for services without flat log files.

    Args:
        params.unit: Systemd unit (optional — omit for all units)
        params.since: Time range string
        params.lines: Max lines
        params.grep: Filter pattern

    Returns:
        str: Journal output
    """
    cmd = ["journalctl", "--no-pager", "-n", str(params.lines)]
    if params.unit:
        cmd += ["-u", params.unit]
    if params.since:
        cmd += ["--since", params.since]
    if params.grep:
        cmd += ["--grep", params.grep]
    r = _run(cmd)
    return r["stdout"] or r["stderr"]


# ---------------------------------------------------------------------------
# ─── NETWORK MONITORING ────────────────────────────────────────────────────
# ---------------------------------------------------------------------------

@mcp.tool(
    name="blueteam_list_listening_ports",
    annotations={"readOnlyHint": True, "destructiveHint": False}
)
async def blueteam_list_listening_ports() -> str:
    """List all TCP/UDP ports currently listening, with owning process.
    Equivalent to 'ss -tulpn'. Identifies unexpected services.

    Returns:
        str: Port table with process names and PIDs
    """
    r = _run(["ss", "-tulpn"])
    if r["returncode"] != 0:
        r = _run(["netstat", "-tulpn"])
    return r["stdout"] or r["stderr"]


@mcp.tool(
    name="blueteam_list_connections",
    annotations={"readOnlyHint": True, "destructiveHint": False}
)
async def blueteam_list_connections() -> str:
    """List all established TCP connections with remote IPs and local processes.
    Useful for spotting unexpected outbound connections (beaconing, exfil).

    Returns:
        str: Active connection table
    """
    r = _run(["ss", "-tnp", "state", "established"])
    if r["returncode"] != 0:
        r = _run(["netstat", "-tnp"])
    return r["stdout"] or r["stderr"]


class CaptureInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    interface: str = Field(default="eth0", description="Network interface to capture on")
    count: int = Field(default=100, description="Number of packets to capture", ge=1, le=5000)
    filter_expr: Optional[str] = Field(default=None, description="BPF filter expression, e.g. 'port 80', 'host 10.0.0.5'")
    output_file: Optional[str] = Field(default=None, description="Optional path to save .pcap file")


@mcp.tool(
    name="blueteam_capture_traffic",
    annotations={"readOnlyHint": False, "destructiveHint": False}
)
async def blueteam_capture_traffic(params: CaptureInput) -> str:
    """Capture live network traffic using tcpdump. Requires root or CAP_NET_RAW.

    Args:
        params.interface: Network interface
        params.count: Packet count to capture then stop
        params.filter_expr: BPF filter (optional)
        params.output_file: Save pcap to this path (optional)

    Returns:
        str: Packet summary or path to saved pcap
    """
    if not shutil.which("tcpdump"):
        return _tool_not_found("tcpdump")

    cmd = ["tcpdump", "-i", params.interface, "-c", str(params.count), "-nn", "-q"]
    if params.filter_expr:
        cmd += params.filter_expr.split()
    if params.output_file:
        cmd += ["-w", params.output_file]

    r = _run(cmd, timeout=60)
    if params.output_file and r["returncode"] == 0:
        return json.dumps({"status": "captured", "file": params.output_file, "packets": params.count})
    return r["stdout"] + r["stderr"]


# ---------------------------------------------------------------------------
# ─── THREAT INTELLIGENCE ──────────────────────────────────────────────────
# ---------------------------------------------------------------------------

class IPInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    ip: str = Field(..., description="IPv4 or IPv6 address to look up")
    max_age_days: int = Field(default=90, description="Only return reports from the last N days", ge=1, le=365)


@mcp.tool(
    name="blueteam_lookup_ip_abuseipdb",
    annotations={"readOnlyHint": True, "destructiveHint": False, "openWorldHint": True}
)
async def blueteam_lookup_ip_abuseipdb(params: IPInput) -> str:
    """Check an IP address against AbuseIPDB for known malicious activity reports.
    Requires ABUSEIPDB_API_KEY environment variable.

    Args:
        params.ip: IP address to check
        params.max_age_days: Lookback window in days

    Returns:
        str: JSON with abuse confidence score, report count, country, ISP, usage type
    """
    if not ABUSEIPDB_API_KEY:
        return json.dumps({
            "error": "ABUSEIPDB_API_KEY not set",
            "fix": "Set environment variable: export ABUSEIPDB_API_KEY=your_key_here",
            "get_key": "https://www.abuseipdb.com/account/api"
        })
    try:
        data = await _http_get(
            "https://api.abuseipdb.com/api/v2/check",
            headers={"Key": ABUSEIPDB_API_KEY, "Accept": "application/json"},
            params={"ipAddress": params.ip, "maxAgeInDays": str(params.max_age_days), "verbose": ""}
        )
        d = data.get("data", {})
        return json.dumps({
            "ip": d.get("ipAddress"),
            "abuse_confidence_score": d.get("abuseConfidenceScore"),
            "total_reports": d.get("totalReports"),
            "last_reported": d.get("lastReportedAt"),
            "country": d.get("countryCode"),
            "isp": d.get("isp"),
            "usage_type": d.get("usageType"),
            "domain": d.get("domain"),
            "is_tor": d.get("isTor"),
            "is_vpn": d.get("isPublic"),
        }, indent=2)
    except httpx.HTTPStatusError as e:
        return json.dumps({"error": f"AbuseIPDB API error: {e.response.status_code}", "detail": e.response.text})
    except Exception as e:
        return json.dumps({"error": str(e)})


class HashInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    hash_value: str = Field(..., description="MD5, SHA1, or SHA256 hash to look up")


@mcp.tool(
    name="blueteam_lookup_hash_virustotal",
    annotations={"readOnlyHint": True, "destructiveHint": False, "openWorldHint": True}
)
async def blueteam_lookup_hash_virustotal(params: HashInput) -> str:
    """Check a file hash against VirusTotal to see if it's known malware.
    Requires VIRUSTOTAL_API_KEY environment variable.

    Args:
        params.hash_value: MD5/SHA1/SHA256 of the file

    Returns:
        str: JSON with detection ratio, malware names, and scan date
    """
    if not VIRUSTOTAL_API_KEY:
        return json.dumps({
            "error": "VIRUSTOTAL_API_KEY not set",
            "fix": "Set environment variable: export VIRUSTOTAL_API_KEY=your_key_here",
            "get_key": "https://www.virustotal.com/gui/my-apikey"
        })
    try:
        data = await _http_get(
            f"https://www.virustotal.com/api/v3/files/{params.hash_value}",
            headers={"x-apikey": VIRUSTOTAL_API_KEY}
        )
        attrs = data.get("data", {}).get("attributes", {})
        stats = attrs.get("last_analysis_stats", {})
        results = attrs.get("last_analysis_results", {})
        # Only include detections (positives)
        detections = {
            engine: r["result"]
            for engine, r in results.items()
            if r.get("category") == "malicious"
        }
        return json.dumps({
            "hash": params.hash_value,
            "name": attrs.get("meaningful_name"),
            "type": attrs.get("type_description"),
            "size_bytes": attrs.get("size"),
            "first_seen": attrs.get("first_submission_date"),
            "last_analysis_date": attrs.get("last_analysis_date"),
            "detections": f"{stats.get('malicious', 0)}/{sum(stats.values())}",
            "malware_names": detections,
        }, indent=2)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            return json.dumps({"result": "Not found in VirusTotal — hash is unknown or clean"})
        return json.dumps({"error": f"VirusTotal API error: {e.response.status_code}"})
    except Exception as e:
        return json.dumps({"error": str(e)})


class DomainInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    domain: str = Field(..., description="Domain name to look up, e.g. 'example.com'")


@mcp.tool(
    name="blueteam_lookup_domain_virustotal",
    annotations={"readOnlyHint": True, "destructiveHint": False, "openWorldHint": True}
)
async def blueteam_lookup_domain_virustotal(params: DomainInput) -> str:
    """Check a domain against VirusTotal for malicious reputation.

    Args:
        params.domain: Domain to check

    Returns:
        str: JSON with reputation score and detection details
    """
    if not VIRUSTOTAL_API_KEY:
        return json.dumps({"error": "VIRUSTOTAL_API_KEY not set. See blueteam_lookup_hash_virustotal for setup."})
    try:
        data = await _http_get(
            f"https://www.virustotal.com/api/v3/domains/{params.domain}",
            headers={"x-apikey": VIRUSTOTAL_API_KEY}
        )
        attrs = data.get("data", {}).get("attributes", {})
        stats = attrs.get("last_analysis_stats", {})
        return json.dumps({
            "domain": params.domain,
            "reputation": attrs.get("reputation"),
            "categories": attrs.get("categories", {}),
            "detections": f"{stats.get('malicious', 0)}/{sum(stats.values())}",
            "registrar": attrs.get("registrar"),
            "creation_date": attrs.get("creation_date"),
            "whois": attrs.get("whois", "")[:500],
        }, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


# ---------------------------------------------------------------------------
# ─── FAIL2BAN ─────────────────────────────────────────────────────────────
# ---------------------------------------------------------------------------

@mcp.tool(
    name="blueteam_fail2ban_status",
    annotations={"readOnlyHint": True, "destructiveHint": False}
)
async def blueteam_fail2ban_status() -> str:
    """List all active fail2ban jails and their ban counts.

    Returns:
        str: Jail list with banned IP counts
    """
    if not shutil.which("fail2ban-client"):
        return _tool_not_found("fail2ban")
    r = _run(["fail2ban-client", "status"])
    return r["stdout"] or r["stderr"]


class JailInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    jail: str = Field(..., description="Jail name, e.g. 'sshd', 'nginx-http-auth'")


@mcp.tool(
    name="blueteam_fail2ban_jail_status",
    annotations={"readOnlyHint": True, "destructiveHint": False}
)
async def blueteam_fail2ban_jail_status(params: JailInput) -> str:
    """Get detailed status of a specific fail2ban jail, including all banned IPs.

    Args:
        params.jail: Jail name

    Returns:
        str: Jail stats and list of currently banned IPs
    """
    if not shutil.which("fail2ban-client"):
        return _tool_not_found("fail2ban")
    r = _run(["fail2ban-client", "status", params.jail])
    return r["stdout"] or r["stderr"]


class UnbanInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    jail: str = Field(..., description="Jail name")
    ip: str = Field(..., description="IP address to unban")


@mcp.tool(
    name="blueteam_fail2ban_unban",
    annotations={"readOnlyHint": False, "destructiveHint": False}
)
async def blueteam_fail2ban_unban(params: UnbanInput) -> str:
    """Unban an IP address from a specific fail2ban jail.

    Args:
        params.jail: Jail name
        params.ip: IP address to unban

    Returns:
        str: Result of unban operation
    """
    if not shutil.which("fail2ban-client"):
        return _tool_not_found("fail2ban")
    r = _run(["fail2ban-client", "set", params.jail, "unbanip", params.ip])
    return r["stdout"] or r["stderr"]


# ---------------------------------------------------------------------------
# ─── FILE INTEGRITY ───────────────────────────────────────────────────────
# ---------------------------------------------------------------------------

class HashFileInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    path: str = Field(..., description="Absolute path to file to hash")
    algorithm: str = Field(default="sha256", description="Hash algorithm: 'md5', 'sha1', 'sha256', 'sha512'")


@mcp.tool(
    name="blueteam_hash_file",
    annotations={"readOnlyHint": True, "destructiveHint": False}
)
async def blueteam_hash_file(params: HashFileInput) -> str:
    """Compute a cryptographic hash of a file. Use to detect tampering.
    Pair with blueteam_lookup_hash_virustotal to check for known malware.

    Args:
        params.path: File path
        params.algorithm: Hash algorithm

    Returns:
        str: JSON with file path, size, hash algorithm, and hash value
    """
    algo_map = {
        "md5": hashlib.md5,
        "sha1": hashlib.sha1,
        "sha256": hashlib.sha256,
        "sha512": hashlib.sha512,
    }
    algo = params.algorithm.lower()
    if algo not in algo_map:
        return json.dumps({"error": f"Unknown algorithm '{params.algorithm}'. Use: md5, sha1, sha256, sha512"})

    p = Path(params.path)
    if not p.exists():
        return json.dumps({"error": f"File not found: {params.path}"})
    if not p.is_file():
        return json.dumps({"error": f"Not a regular file: {params.path}"})

    try:
        h = algo_map[algo]()
        with open(p, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        return json.dumps({
            "path": str(p),
            "size_bytes": p.stat().st_size,
            "algorithm": algo,
            "hash": h.hexdigest(),
            "modified": datetime.fromtimestamp(p.stat().st_mtime).isoformat(),
        }, indent=2)
    except PermissionError:
        return json.dumps({"error": f"Permission denied reading {params.path}"})
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool(
    name="blueteam_find_suid_files",
    annotations={"readOnlyHint": True, "destructiveHint": False}
)
async def blueteam_find_suid_files() -> str:
    """Find all SUID/SGID binaries on the system. Unexpected SUID files
    can indicate privilege escalation backdoors.

    Returns:
        str: List of SUID/SGID files with permissions and owner
    """
    r = _run(["find", "/", "-type", "f", r"-perm", "/6000", "-ls"], timeout=60)
    return r["stdout"] or r["stderr"]


@mcp.tool(
    name="blueteam_find_world_writable",
    annotations={"readOnlyHint": True, "destructiveHint": False}
)
async def blueteam_find_world_writable() -> str:
    """Find world-writable files and directories (excluding /proc, /sys, /dev).
    World-writable files in unexpected places are common persistence mechanisms.

    Returns:
        str: List of world-writable paths
    """
    cmd = [
        "find", "/",
        "-not", "-path", "/proc/*",
        "-not", "-path", "/sys/*",
        "-not", "-path", "/dev/*",
        "-not", "-path", "/run/*",
        "-perm", "-o+w",
        "-ls"
    ]
    r = _run(cmd, timeout=60)
    return r["stdout"] or r["stderr"]


class RootkitInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    tool: str = Field(default="rkhunter", description="Tool to use: 'rkhunter' or 'chkrootkit'")


@mcp.tool(
    name="blueteam_rootkit_scan",
    annotations={"readOnlyHint": True, "destructiveHint": False}
)
async def blueteam_rootkit_scan(params: RootkitInput) -> str:
    """Run a rootkit scanner (rkhunter or chkrootkit) to check for known rootkits.

    Args:
        params.tool: Scanner to use

    Returns:
        str: Scan output with warnings and clean checks
    """
    tool = params.tool.lower()
    if tool == "rkhunter":
        if not shutil.which("rkhunter"):
            return _tool_not_found("rkhunter")
        r = _run(["rkhunter", "--check", "--skip-keypress", "--nocolors"], timeout=120)
    elif tool == "chkrootkit":
        if not shutil.which("chkrootkit"):
            return _tool_not_found("chkrootkit")
        r = _run(["chkrootkit"], timeout=120)
    else:
        return json.dumps({"error": f"Unknown tool '{tool}'. Use 'rkhunter' or 'chkrootkit'"})

    return r["stdout"] or r["stderr"]


# ---------------------------------------------------------------------------
# ─── SYSTEM HARDENING ─────────────────────────────────────────────────────
# ---------------------------------------------------------------------------

@mcp.tool(
    name="blueteam_lynis_audit",
    annotations={"readOnlyHint": True, "destructiveHint": False}
)
async def blueteam_lynis_audit() -> str:
    """Run a Lynis system hardening audit. Checks hundreds of security controls
    and produces prioritized recommendations. Takes 1-2 minutes.

    Returns:
        str: Lynis audit output with hardening index and suggestions
    """
    if not shutil.which("lynis"):
        return _tool_not_found("lynis")
    r = _run(["lynis", "audit", "system", "--quick", "--no-colors"], timeout=180)
    return r["stdout"] or r["stderr"]


@mcp.tool(
    name="blueteam_check_updates",
    annotations={"readOnlyHint": True, "destructiveHint": False}
)
async def blueteam_check_updates() -> str:
    """Check for available security updates (Debian/Ubuntu: apt, RHEL: dnf/yum).

    Returns:
        str: List of packages with available updates
    """
    if shutil.which("apt"):
        r = _run(["apt", "list", "--upgradeable"], timeout=60)
        return r["stdout"] or r["stderr"]
    elif shutil.which("dnf"):
        r = _run(["dnf", "check-update", "--security"], timeout=60)
        return r["stdout"] or r["stderr"]
    elif shutil.which("yum"):
        r = _run(["yum", "check-update", "--security"], timeout=60)
        return r["stdout"] or r["stderr"]
    return json.dumps({"error": "No supported package manager found (apt, dnf, yum)"})


@mcp.tool(
    name="blueteam_check_open_firewall",
    annotations={"readOnlyHint": True, "destructiveHint": False}
)
async def blueteam_check_open_firewall() -> str:
    """Show current firewall rules (iptables/nftables/ufw). Identifies
    overly permissive rules or missing protections.

    Returns:
        str: Current firewall ruleset
    """
    if shutil.which("ufw"):
        r = _run(["ufw", "status", "verbose"])
        if r["returncode"] == 0:
            return r["stdout"]
    if shutil.which("nft"):
        r = _run(["nft", "list", "ruleset"])
        if r["returncode"] == 0:
            return r["stdout"]
    r = _run(["iptables", "-L", "-n", "-v"])
    return r["stdout"] or r["stderr"]


# ---------------------------------------------------------------------------
# ─── USER & SESSION MONITORING ────────────────────────────────────────────
# ---------------------------------------------------------------------------

@mcp.tool(
    name="blueteam_who_is_logged_in",
    annotations={"readOnlyHint": True, "destructiveHint": False}
)
async def blueteam_who_is_logged_in() -> str:
    """Show currently logged-in users, their source IPs, and session times.
    Useful for detecting unauthorized active sessions.

    Returns:
        str: Active user session table
    """
    r = _run(["w", "-h"])
    return r["stdout"] or r["stderr"]


@mcp.tool(
    name="blueteam_last_logins",
    annotations={"readOnlyHint": True, "destructiveHint": False}
)
async def blueteam_last_logins() -> str:
    """Show recent login history from /var/log/wtmp. Includes successful
    and failed logins with source IP and timestamps.

    Returns:
        str: Login history (last 50 entries)
    """
    r = _run(["last", "-n", "50", "-a", "-i"])
    return r["stdout"] or r["stderr"]


@mcp.tool(
    name="blueteam_failed_logins",
    annotations={"readOnlyHint": True, "destructiveHint": False}
)
async def blueteam_failed_logins() -> str:
    """Show all failed login attempts from /var/log/btmp (lastb).
    High counts from a single IP indicate brute force.

    Returns:
        str: Failed login history (last 100 entries)
    """
    r = _run(["lastb", "-n", "100", "-a", "-i"])
    if r["returncode"] != 0:
        # Try parsing auth.log directly
        r2 = _run(["grep", "-i", "failed password\|authentication failure", "/var/log/auth.log"])
        lines = r2["stdout"].splitlines()
        return "\n".join(lines[-100:]) if lines else "No failed logins found in auth.log"
    return r["stdout"] or r["stderr"]


@mcp.tool(
    name="blueteam_sudo_history",
    annotations={"readOnlyHint": True, "destructiveHint": False}
)
async def blueteam_sudo_history() -> str:
    """Show recent sudo command usage from auth.log.
    Identifies privilege escalation abuse.

    Returns:
        str: Lines from auth.log containing sudo activity
    """
    r = _run(["grep", "sudo:", "/var/log/auth.log"])
    lines = r["stdout"].splitlines()
    return "\n".join(lines[-200:]) if lines else "No sudo activity found (or no auth.log)"


@mcp.tool(
    name="blueteam_list_users",
    annotations={"readOnlyHint": True, "destructiveHint": False}
)
async def blueteam_list_users() -> str:
    """List all local user accounts with UID, GID, home dir, and shell.
    Highlights users with UID 0 (root-level) and users with login shells.

    Returns:
        str: JSON array of user accounts with risk flags
    """
    users = []
    try:
        with open("/etc/passwd") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                parts = line.split(":")
                if len(parts) < 7:
                    continue
                uid = int(parts[2])
                shell = parts[6]
                has_login_shell = shell not in ["/sbin/nologin", "/usr/sbin/nologin", "/bin/false", ""]
                users.append({
                    "username": parts[0],
                    "uid": uid,
                    "gid": int(parts[3]),
                    "home": parts[5],
                    "shell": shell,
                    "flags": {
                        "uid_zero_root": uid == 0,
                        "has_login_shell": has_login_shell,
                        "system_account": uid < 1000 and uid != 0,
                    }
                })
    except Exception as e:
        return json.dumps({"error": str(e)})

    # Sort: UID 0 first, then regular users, then system accounts
    users.sort(key=lambda u: (not u["flags"]["uid_zero_root"], not u["flags"]["has_login_shell"], u["uid"]))
    return json.dumps(users, indent=2)


@mcp.tool(
    name="blueteam_check_ssh_authorized_keys",
    annotations={"readOnlyHint": True, "destructiveHint": False}
)
async def blueteam_check_ssh_authorized_keys() -> str:
    """List all SSH authorized_keys files across all user home directories.
    Unexpected keys indicate backdoors or persistence mechanisms.

    Returns:
        str: JSON with each user's authorized keys (fingerprints)
    """
    result = {}
    for home in Path("/home").iterdir():
        ak = home / ".ssh" / "authorized_keys"
        if ak.exists():
            try:
                result[home.name] = ak.read_text().strip().splitlines()
            except PermissionError:
                result[home.name] = ["<permission denied>"]

    # Also check root
    root_ak = Path("/root/.ssh/authorized_keys")
    if root_ak.exists():
        try:
            result["root"] = root_ak.read_text().strip().splitlines()
        except PermissionError:
            result["root"] = ["<permission denied>"]

    return json.dumps(result, indent=2) if result else json.dumps({"result": "No authorized_keys files found"})


# ---------------------------------------------------------------------------
# ─── PROCESS & CRON ANALYSIS ──────────────────────────────────────────────
# ---------------------------------------------------------------------------

@mcp.tool(
    name="blueteam_list_processes",
    annotations={"readOnlyHint": True, "destructiveHint": False}
)
async def blueteam_list_processes() -> str:
    """List all running processes with CPU, memory, PID, and command line.
    Useful for spotting unexpected processes or cryptominers.

    Returns:
        str: Process table sorted by CPU usage
    """
    r = _run(["ps", "auxf"])
    return r["stdout"] or r["stderr"]


@mcp.tool(
    name="blueteam_list_cron_jobs",
    annotations={"readOnlyHint": True, "destructiveHint": False}
)
async def blueteam_list_cron_jobs() -> str:
    """List all system and user cron jobs. Attackers often add cron jobs
    for persistence. Check for unexpected entries.

    Returns:
        str: All cron jobs across system and users
    """
    output = []

    # System crontabs
    for path in ["/etc/crontab", "/etc/cron.d/"]:
        p = Path(path)
        if p.is_file():
            output.append(f"=== {path} ===\n{p.read_text()}")
        elif p.is_dir():
            for f in p.iterdir():
                try:
                    output.append(f"=== {f} ===\n{f.read_text()}")
                except Exception:
                    pass

    # User crontabs
    r = _run(["ls", "/var/spool/cron/crontabs"])
    if r["returncode"] == 0:
        for user in r["stdout"].strip().splitlines():
            r2 = _run(["crontab", "-u", user.strip(), "-l"])
            if r2["returncode"] == 0:
                output.append(f"=== crontab for {user} ===\n{r2['stdout']}")

    return "\n\n".join(output) if output else "No cron jobs found (or insufficient permissions)"


# ---------------------------------------------------------------------------
# ─── SYSTEM HEALTH ────────────────────────────────────────────────────────
# ---------------------------------------------------------------------------

@mcp.tool(
    name="blueteam_system_health",
    annotations={"readOnlyHint": True, "destructiveHint": False}
)
async def blueteam_system_health() -> str:
    """Get an overview of system health: uptime, disk, memory, CPU load.
    Useful baseline before deeper investigation.

    Returns:
        str: JSON with system vitals
    """
    uptime = _run(["uptime", "-p"])
    disk = _run(["df", "-h", "--exclude-type=tmpfs", "--exclude-type=devtmpfs"])
    mem = _run(["free", "-h"])
    load = _run(["cat", "/proc/loadavg"])
    hostname = _run(["hostname", "-f"])
    kernel = _run(["uname", "-r"])

    return json.dumps({
        "hostname": hostname["stdout"].strip(),
        "kernel": kernel["stdout"].strip(),
        "uptime": uptime["stdout"].strip(),
        "load_average": load["stdout"].strip(),
        "memory": mem["stdout"],
        "disk": disk["stdout"],
        "timestamp": datetime.utcnow().isoformat() + "Z",
    }, indent=2)


# ---------------------------------------------------------------------------
# ─── ENTRY POINT ──────────────────────────────────────────────────────────
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    mcp.run()
